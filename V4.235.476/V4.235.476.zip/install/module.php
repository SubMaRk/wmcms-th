<?php
//wm_system_menu表的菜单id
$module = array(
	'novel'=>array('id'=>'74','name'=>'小说模块','checked'=>'checked onClick="alert(\'默认模块必须安装！\');return false;"'),
	'user'=>array('id'=>'107','name'=>'用户模块','checked'=>'checked onClick="alert(\'默认模块必须安装！\');return false;"'),
	'replay'=>array('id'=>'131','name'=>'评论模块','checked'=>'checked onClick="alert(\'默认模块必须安装！\');return false;"'),
	'search'=>array('id'=>'136','name'=>'搜索模块','checked'=>'checked onClick="alert(\'默认模块必须安装！\');return false;"'),
	'author'=>array('id'=>'92','name'=>'作者模块'),
	'article'=>array('id'=>'26','name'=>'文章模块'),
	'link'=>array('id'=>'119','name'=>'友链模块'),
	'picture'=>array('id'=>'43','name'=>'图集模块'),
	'diy'=>array('id'=>'152','name'=>'单页模块'),
	'zt'=>array('id'=>'149','name'=>'专题模块'),
	'message'=>array('id'=>'144','name'=>'留言模块'),
	'app'=>array('id'=>'61','name'=>'应用模块'),
	'about'=>array('id'=>'36','name'=>'关于模块'),
	'bbs'=>array('id'=>'52','name'=>'论坛模块','checked'=>'disabled'),
	'down'=>array('id'=>'0','name'=>'下载模块'),
);
?>