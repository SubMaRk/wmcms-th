<div class="main cc">
	<div class="success_tip error_tip" style="margin-bottom: 30px;">
	<p>对不起，安装包不存在sql.sql数据库文件无法进行安装。</p>
	</div>
	<div class="bottom tac">
	<a href="javascript:;" onclick="javascript:history.go(-1);return false;" class="btn">返 回</a>
	</div>
</div>