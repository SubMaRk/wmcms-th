<div class="main cc">
	<div class="success_tip error_tip" style="margin-bottom: 30px;">
	<p>您已经安装过 wmcms，如需重新安装，请删除此文件（/wmcms/config/install.lock.txt）再进行安装</p>
	</div>
	<div class="bottom tac">
	<a href="javascript:;" onclick="javascript:history.go(-1);return false;" class="btn">返 回</a>
	</div>
</div>