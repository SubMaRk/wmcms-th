<?php
/**
* 公共事件处理文件
* @version        $Id: config.php 2018年6月9日 9:43  weimeng
* @package        WMCMS
* @copyright      Copyright (c) 2015 WeiMengCMS, Inc.
* @link           http://www.weimengcms.com
*
*/
C('plugin.demo.end','这是从公共事件处理文件替换的后的end配置');
?>