<?php
/**
* 插件配置文件
* @name 		     命名方法：plugin.模块文件夹名.参数域名
* @version        $Id: config.php 2018年6月9日 9:43  weimeng
* @package        WMCMS
* @copyright      Copyright (c) 2015 WeiMengCMS, Inc.
* @link           http://www.weimengcms.com
*
*/
//键为default_action表示插件的默认入口方法
C('plugin.demo',array(
	'base'=>'这是测试基本配置',
	'end'=>'结束语言',
));
?>