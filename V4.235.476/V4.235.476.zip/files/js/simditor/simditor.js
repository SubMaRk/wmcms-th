document.write('<link rel="stylesheet" type="text/css" href="/files/js/simditor/styles/simditor.css" />');
document.write('<script src="/files/js/simditor/scripts/module.min.js"></script>');
document.write('<script src="/files/js/simditor/scripts/hotkeys.min.js"></script>');
document.write('<script src="/files/js/simditor/scripts/uploader.js"></script>');
document.write('<script src="/files/js/simditor/scripts/simditor.js"></script>');
document.write('<script src="/files/js/simditor/scripts/simditor-dropzone.js"></script>');
document.write('<script src="/files/js/simditor/scripts/simditor-autosave.js"></script>');