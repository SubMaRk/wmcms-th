//公共jquery库
document.write('<script src="/files/js/jquery-3.0.0.min.js"></script>');
//document.write('<script src="/files/js/jquery-1.11.3.min.js"></script>');
//document.write('<script src="/files/js/jquery-1.4.3.min.js"></script>');
//document.write('<script src="/files/js/jquery-1.4.2.min.js"></script>');

//公共函数库
document.write('<script src="/files/js/function.js"></script>');

//简单弹窗提示
document.write('<script src="/files/js/easydialog/easydialog.js"></script>');
document.write('<link rel="stylesheet" type="text/css" href="/files/js/easydialog/easydialog.css" />');