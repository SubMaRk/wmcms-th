<?php
/**
* 全系统收藏验证处理器
*
* @version        $Id: index.php 2015年8月15日 10:31  weimeng
* @package        WMCMS
* @copyright      Copyright (c) 2015 WeiMengCMS, Inc.
* @link           http://www.weimengcms.com
* @uptime 		  2016年5月25日 20:42  weimeng
*
*/
$linkConfig = GetModuleConfig('link');

require_once $type.'.php';
?>