<?php
$lang['dingcai']= array(
	'module'=>'对不起，请求模块不能为空！',
	'type'=>'对不起，操作类型不正确！',
	'cid_err'=>'对不起，评价内容id不能为空！',
	'module_no'=>'对不起，操作的模块不存在！',

	'dingcai_no'=>'对不起，需要评价的内容ID不存在！',

	'dingcai_count'=>'对不起,同一内容每天只能评价{次数}次!',
	'dingcai_close'=>'对不起,当前模块评价功能已经关闭!',
	'dingcai_login'=>'对不起，需要登录才能进行评价!',
);

$lang['operate']= array(
	'dingcai'=>array('success'=>'恭喜您，操作成功！','fail'=>'对不起，操作失败！'),
);
?>