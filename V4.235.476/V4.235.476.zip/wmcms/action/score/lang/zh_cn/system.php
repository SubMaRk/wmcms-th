<?php
$lang['score']= array(
	'type'=>'对不起，请求类型不能为空！',
	'type_no'=>'对不起，当前评分表不存在！',
	'module'=>'对不起，请求模块不能为空！',
	'content_no'=>'对不起，需要评分的内容不存在！',
	'cid_err'=>'对不起，内容ID只能为数字！',
	'score_err'=>'对不起，分数只能为数字！',
	'score_no'=>'对不起，分数值范围不正确！',
		
	'score_close'=>'对不起，当前模块评分功能已经关闭！',
	'score_count'=>'对不起,同一内容每天只能评分{次数}次!',
);

$lang['score']['operate']= array(
	'score'=>array('success'=>'恭喜您，评分成功！','fail'=>'对不起，评分失败！'),
);
?>