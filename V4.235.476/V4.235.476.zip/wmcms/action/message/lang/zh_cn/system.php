<?php
$lang['message']= array(
	'type_no'=>'对不起，操作类型错误！',
	'content_no'=>'对不起，留言内容不能为空！',
	'content_err'=>'对不起，留言内容必须在10到1000个字符之间！',
	'close'=>'对不起，留言系统已经关闭！',
	'count'=>'对不起，每天只能留言{次数}次！',
);

$lang['message']['operate']= array(
	'success'=>'恭喜您，留言成功！',
	'fail'=>'对不起，留言失败！',
);
?>