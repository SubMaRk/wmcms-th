<?php
$lang['replay']= array(
	'par'=>'对不起,所有项不能为空!',
	'type'=>'对不起，请求类型不能为空！',
	'type_err'=>'对不起，请求类型错误！',
	'close'=>'对不起,评论系统已经关闭!',
	'login'=>'对不起,需要登录才能评论!',
	'module'=>'对不起,评论模块不正确!',
	'content'=>'对不起,内容长度为4到500个字符!',
		
	'module_no'=>'对不起，操作的模块不存在！',

	'everyday_limit'=>'对不起,每天只能评论{条数}条!',
	'replay_no'=>'对不起,评论的内容不存在!',
		
	'success'=>'获取成功！',
	'fail'=>'获取失败！',
		
	'top_time'=>'对不起，两次评论的时间不能小于{间隔}秒！',

	'bbs_close'=>'对不起,此版块已经关闭了回帖!',
	'bbs_login'=>'对不起,需要登录才能回帖!',
);

$lang['operate']= array(
	'replay'=>array('success'=>'恭喜您，评论成功！','fail'=>'对不起，评论失败！',),
	'bbs'=>array('success'=>'恭喜您，回帖成功！','fail'=>'对不起，回帖失败！',),
);
?>