<?php
/**
* 小说模块验证处理器
*
* @version        $Id: index.php 2017年3月18日 14:31  weimeng
* @package        WMCMS
* @copyright      Copyright (c) 2015 WeiMengCMS, Inc.
* @link           http://www.weimengcms.com
*
*/
require_once $type.'.php';
?>