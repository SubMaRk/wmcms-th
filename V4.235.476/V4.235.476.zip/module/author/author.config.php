<?php $authorConfig=array('author_article_open' => '1','apply_author_status' => '0','apply_author_open' => '1','author_default_info' => '这个人很懒呢！','author_default_notice' => '此作者暂时没有公告！','author_novel_createnovel' => '0','author_novel_createchapter' => '0','author_novel_coverwidth' => '400','author_novel_coverheight' => '500','author_novel_uploadcover' => '0','author_apply_0' => '您好，您的作者申请已经提交，请等待管理员审核！。','author_apply_1' => '您好，您申请的作者已经通过审核，现在您可以去创建小说了！','author_apply_2' => '对不起，您申请的作者没有通过审核！
原因如下：
1.可能资料不完善
2.你的笔名涉嫌违法','author_novel_cover_0' => '您好，您上传的封面请等待管理员审核通过后才能显示！','author_novel_cover_1' => '恭喜您，您提交的小说封面审核通过！','author_novel_cover_2' => '对不起，您申请的封面没有通过审核！
原因如下：
1.可能封面涉黄、暴力！
2.违法国家相关法律！','author_novel_editnovel' => '0','author_novel_editchapter' => '0','author_novel_editnovel_0' => '您好，您编辑的小说请等待管理员审核！','author_novel_editnovel_1' => '恭喜您，您提交的小说信息审核通过！','author_novel_editnovel_2' => '对不起，您编辑的小说没有通过审核！
原因如下：
1.可能内容涉黄、暴力！
2.违法国家相关法律！','author_novel_editchapter_0' => '您好，您编辑的章节请等待管理员审核！','author_novel_editchapter_1' => '恭喜您，您的章节审核通过！','author_novel_editchapter_2' => '对不起，您编辑的章节没有通过审核！
原因如下：
1.可能内容涉黄、暴力！
2.违法国家相关法律！','author_article_createarticle' => '0','author_article_editarticle' => '0','author_article_editarticle_0' => '您好，请等待管理员审核您的稿件！','author_article_editarticle_1' => '恭喜您，您的投稿已经审核通过！','author_article_editarticle_2' => '对不起，您的投稿没有通过审核！
原因如下：
1.可能内容涉黄、暴力！
2.违法国家相关法律！','login_exp' => '10','income_rec' => '5','income_month' => '10','income_gold1' => '100','income_gold2' => '50',);?>