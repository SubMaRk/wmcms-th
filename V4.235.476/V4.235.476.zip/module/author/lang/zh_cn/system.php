<?php
//参数相关
$lang['author']['par'] = array(
	'apply_author_close'=>'对不起,管理员暂时关闭了新的作家申请！',
	'apply_author_status_0'=>'对不起，您已经提交了作家申请，请等待管理员处理您的申请！',
	'apply_author_status_1'=>'对不起，您已经成为作家了，无需再次申请！',

	'novel_no'=>'对不起，小说不存在！',
	'novel_chapterType_0'=>'公众章节',
	'novel_chapterType_1'=>'收费章节',
);
return $lang;
?>