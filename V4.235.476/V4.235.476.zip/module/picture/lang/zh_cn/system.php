<?php
//参数相关
$lang['picture']['par'] = array(
	'tid_no'=>'对不起,tid必须填写！',
	'key_no'=>'对不起,搜索词不能为空！',
	'key_err'=>'对不起,搜索词长度为2-16个字符！',
		
	'pid_err'=>'对不起,pid必须为数字！',
	'tid_err'=>'对不起,tid必须为数字！',
);
?>