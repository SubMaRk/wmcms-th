<?php
$aboutConfig = array(
	'par_type_int'=>true,
	'par_about_int'=>true,
);
?>