<?php
//参数相关
$lang['about']['par'] = array(
	'type_err'=>'对不起,tid必须为数字！',
	'about_err'=>'对不起,aid只能为数字！',
);
?>