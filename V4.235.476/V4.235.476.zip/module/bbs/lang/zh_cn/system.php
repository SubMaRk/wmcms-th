<?php
//参数相关
$lang['bbs'] = array(
	'top_1'=>'全站置顶',
	'top_2'=>'分类置顶',
	'top_3'=>'当前置顶',
	'status_1'=>'已审核',
	'status_0'=>'待审核',
	'type_tid_no'=>'对不起,版块分类id不能为空！',
		
	'type_tid_no'=>'对不起,tid不能为空！',
	'type_bid_err'=>'对不起,bid只能为数字！',
		
	'bid_err'=>'对不起,bid必须为数字！',
	'tid_err'=>'对不起,tid必须为数字！',
	'type_manager_no'=>'暂无版主',
		
	'bbs_status_0'=>'对不起，此帖子正在审核中！',
	'bbs_noup'=>'对不起，不允许作者自己修改！',
	
	'bbs_noauthor'=>'对不起，您没有操作权限！',

	'key_no'=>'对不起,搜索词不能为空！',
	'key_err'=>'对不起,搜索词长度为2-16个字符！',
		
	'post_tid_err'=>'对不起,版块id错误！',
);
?>