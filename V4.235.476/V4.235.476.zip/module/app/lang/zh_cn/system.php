<?php
//参数相关
$lang['app']['par'] = array(
	'tid_no'=>'对不起,tid必须填写！',
	'key_no'=>'对不起,搜索词不能为空！',
	'key_err'=>'对不起,搜索词长度为2-16个字符！',
		
	'aid_err'=>'对不起,aid必须为数字！',
	'tid_err'=>'对不起,tid必须为数字！',
	'lid_err'=>'对不起,lid必须为数字！',
	'cid_err'=>'对不起,cid必须为数字！',
	'ot_err'=>'对不起,ot必须为数字！',
	'pid_err'=>'对不起,pid必须为数字！',
);

$lang['app']['attr'] = array(
	'tocn'=>'已汉化',

	'no_tocn'=>'未汉化',
	'no_lang'=>'中文',
	'no_cost'=>'免费',
	'no_platform'=>'通用',
	'no_developers'=>'未知',
	'no_operators'=>'未知',
);
?>