<?php
//参数相关
$lang['down']['par'] = array(
	'module_no'=>'对不起,内容模块不能为空！',
	'err'=>'对不起,参数错误！',
);
?>