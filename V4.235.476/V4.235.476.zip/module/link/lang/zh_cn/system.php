<?php
//参数相关
$lang['link']['par'] = array(
	'tid_no'=>'对不起,tid必须填写！',
	'lid_err'=>'对不起,lid必须为数字！',
	'tid_err'=>'对不起,tid必须为数字！',
	'type_err'=>'对不起,友链点击类型错误！',

	'link_no'=>'对不起,友链友链不存在！',
		
	'join_close'=>'对不起，友链申请功能已被系统关闭！',
	'show_close'=>'对不起,友链展示已经关闭！',

	'status_0'=>'对不起,友链正在审核中！',
	'show_close'=>'对不起,友链展示已经关闭！',

	'ip_close'=>'未开启IP统计',
	'address_close'=>'未开启地址统计',
);
?>