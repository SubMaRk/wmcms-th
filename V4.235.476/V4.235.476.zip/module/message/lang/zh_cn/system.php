<?php
//参数相关
$lang['message']['par'] = array(
	'tid_no'=>'对不起,tid必须填写！',
);
?>