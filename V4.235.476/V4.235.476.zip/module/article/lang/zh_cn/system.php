<?php
//参数相关
$lang['article']['par'] = array(
	'tid_no'=>'对不起,tid必须填写！',
	'key_no'=>'对不起,搜索词不能为空！',
	'key_err'=>'对不起,搜索词长度为2-16个字符！',
		
	'aid_err'=>'对不起,aid必须为数字！',
	'tid_err'=>'对不起,tid必须为数字！',
	
	'article_display'=>'对不起,该文章已被管理员关闭！',
		
	'status_0'=>'审核中',
	'status_1'=>'已通过',
	'status_2'=>'已拒绝',
);
?>