<?php
//参数相关
$lang['zt']['par'] = array(
	'tid_no'=>'对不起,tid必须填写！',
	'tid_err'=>'对不起,tid必须为数字！',
	'zid_no'=>'对不起,zid必须填写！',
	'zid_err'=>'对不起,zid必须为数字！',
);
?>