<?php
//参数相关
$lang['diy']['par'] = array(
	'did_no'=>'对不起,did必须填写！',
	'did_err'=>'对不起,did必须为数字！',
);
?>